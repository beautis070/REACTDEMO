import React from "react";
import classes from "./FooterSection.module.css";
import { FiInstagram, FiFacebook, FiTwitter } from "react-icons/fi";
export default function FooterSection() {
  return (
    <div className={classes["footer"]}>
      <div className={classes["footer-icon"]}>
        <div className={classes["icons"]}>
          <a href='#'>
            <FiInstagram size={25} />
          </a>
        </div>
        <div className={classes["icons"]}>
          <a href='#'>
            <FiFacebook size={25} />
          </a>
        </div>
        <div className={classes["icons"]}>
          <a href='#'>
            <FiTwitter size={25} />
          </a>
        </div>
      </div>
      <div className={classes["footer-text"]}>
        <h2>We are all Elemental</h2>
      </div>
      <div className={classes["footer-sub-text"]}>
        <div className={classes["text-footer"]}>
          <a href='#'>About Us</a>
          <a href='#'>Contact Us</a>
          <a href='#'>Terms and conditions</a>
          <a href='#'>Privacy policy</a>
        </div>
        <a href='#' className={classes["text-right"]}>
          Designed and built by SDRS
        </a>
      </div>
    </div>
  );
}
