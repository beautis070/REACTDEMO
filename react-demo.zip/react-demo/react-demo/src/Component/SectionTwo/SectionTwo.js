import React from "react";
import classes from "./SectionTwo.module.css";
import { FcIdea, FcAlarmClock } from "react-icons/fc";

export default function SectionTwo() {
  return (
    <div className={classes["section-two-bg"]}>
      <div className={classes["section-two-left"]}>
        <h3>Study the way u like it</h3>

        <p>
          Choose between practice and exam
          <br />
          modes to complete your workbooks.
        </p>
      </div>
      <div className={classes["section-two-right"]}>
        <div className={classes["section-two-right-box1"]}>
          <FcIdea />
          <h4>Practice</h4>
          <p>
            Check your answers and learn as you go, Build a streak for every
            correct answer.
          </p>
        </div>
        <div
          id={classes["right-box-id"]}
          className={classes["section-two-right-box1"]}>
          <FcAlarmClock />
          <h2>Exam</h2>
          <p>
            Complete under timed conditions then check your answer at the end.
          </p>
        </div>
      </div>
    </div>
  );
}
