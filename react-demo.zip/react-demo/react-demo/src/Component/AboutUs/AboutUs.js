import React from "react";
import classes from "./About.css";

export default function AboutUs() {
  return <div className={classes["about"]}></div>;
}
