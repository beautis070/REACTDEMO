import React from "react";
import classes from "./Navbar.module.css";
import { HiShoppingCart } from "react-icons/hi";
import { Link } from "react-router-dom";

export default function Navbar() {
  return (
    <>
      <div>
        <nav className='d-flex justify-content-around'>
          <div className='my-3 '>
            <p className={classes["headings"]}>
              We all are <br />
              <span>Elemental</span>
            </p>
          </div>
          <div className='d-flex flex-row mb-3 my-3'>
            <a href='#' className='p-2 mx-3'>
              Shop
            </a>
            <Link to='/about' className='p-2 mx-3'>
              About Us
            </Link>
            <a href='#' className='p-2 mx-3'>
              My workbooks
            </a>
          </div>

          <div className='nav--right my-3'>
            <button
              type='button'
              className='btn border border-dark mx-3 '
              style={{ boxShadow: "0px 4px 0px #8A8A8A" }}>
              Log in
            </button>
            <button
              type='button'
              className='btn btn-primary mx-3'
              style={{ boxShadow: "0px 4px 0px #99CDFF" }}>
              Sign up
            </button>
            <HiShoppingCart size='28' className='my-3' />
          </div>
        </nav>
      </div>
    </>
  );
}
