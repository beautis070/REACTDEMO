import React, { Fragment } from "react";
import image7 from "./image7.png";
import classes from "./SectionThree.module.css";
export default function SectionThree() {
  return (
    <Fragment>
      <div className={classes["section-four"]}>
        <div className={classes["section-four-box2"]}>
          <div style={{ width: "50px", height: "50px" }}>
            <img
              src={image7}
              alt='image7'
              style={{
                width: "190px",
                height: "190px",
                marginLeft: "20px",
                marginTop: "80px",
              }}
            />
          </div>
          <div className={classes["bob"]}>
            <img
              src={image7}
              alt='image7'
              style={{ width: "190px", height: "190px", marginLeft: "-35px" }}
            />
            <img
              src={image7}
              alt='image7'
              style={{
                width: "190px",
                height: "190px",
                marginLeft: "-35px",
                marginTop: "-110px",
              }}
            />
          </div>
        </div>
        <div className={classes["section-four-box1"]}>
          <h3>Workbooks for your studies</h3>
          <p className={classes["para"]}>
            Discover workbook by courses and syllabus learning outcomes to fill
            your knowledge gaps.
          </p>
          <button className={classes["btn"]}>IB</button>
          <button className={classes["btn1"]}>HSC</button>
          <button className={classes["btn1"]}>VCE</button>
        </div>
      </div>
    </Fragment>
  );
}
