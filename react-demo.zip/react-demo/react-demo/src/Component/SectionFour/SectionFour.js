import React from "react";
import classes from "./SectionFour.module.css";
import Female from "./Female.png";
export default function SectionFour() {
  return (
    <div className={classes["section-four"]}>
      <div className={classes["box1"]}>
        <h3>What student says about our workbooks</h3>
      </div>
      <div className={classes["box2"]}>
        <div className='d-flex bd-highlight'>
          <div className='p-2 w-100 bd-highlight'>
            <img
              src={Female}
              alt='female'
              style={{
                width: "140px",
                height: "90px",
                marginLeft: "10px",
              }}
            />
          </div>
          <div className='p-2 flex-shrink-1 bd-highlight py-3'>
            <p className={classes["para"]}>
              “We Are All Elemental really helped me prepare for my HSC exam. I
              found the workbooks make what we were learning in class more...” -
              Claire
            </p>
          </div>
        </div>
      </div>
      <div className={classes["box3"]}>
        <div className='d-flex bd-highlight'>
          <p className={classes["para1"]}>
            “We Are All Elemental really helped me prepare for my HSC exam. I
            found the workbooks make what we were learning in class more...” -
            Claire
          </p>
          <div className='p-2 flex-shrink-1 bd-highlight py-3'>
            <div className='p-2 w-100 bd-highlight'>
              <img
                src={Female}
                alt='female'
                style={{
                  width: "140px",
                  height: "90px",
                  marginLeft: "10px",
                }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
