import React, { Fragment } from "react";
import Male from "./Male-1.png";
import classes from "./SectionOne.module.css";
export default function SectionOne() {
  return (
    <Fragment>
      <div className={classes["bg"]}>
        <div className={classes["div-1"]}>
          <img src={Male} alt='Male image' />
        </div>
        <div className={classes["div-2"]}>
          <h1>
            Easy Peasy
            <br /> Lemon Squeezy
          </h1>
          <h5>
            Master Chemistry with
            <br /> our online workbooks
          </h5>
        </div>
      </div>
    </Fragment>
  );
}
