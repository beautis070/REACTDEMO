import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Footer from "./Component/Footer/FooterSection";
import Navbar from "./Component/Navbar/Navbar";
import SectionFour from "./Component/SectionFour/SectionFour";
import SectionOne from "./Component/SectionOne/SectionOne";
import SectionThree from "./Component/SectionThree/SectionThree";
import SectionTwo from "./Component/SectionTwo/SectionTwo";
import AboutUs from "./Component/AboutUs/AboutUs";
function App() {
  return (
    <Router>
      <div>
        <Navbar />
        <SectionOne />
        <SectionTwo />
        <SectionThree />
        <SectionFour />
        <Footer />

        <Routes>
          <Route path='/about' element={<AboutUs />}></Route>
        </Routes>
      </div>
    </Router>
  );
}

export default App;
